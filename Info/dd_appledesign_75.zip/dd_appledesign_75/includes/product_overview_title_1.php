<?php
function product_overview_title_1($object) {
?>
    <h2 class=" bd-productoverviewtitle-1"><?php echo $object->productTitle->name; ?></h2>
<?php
}