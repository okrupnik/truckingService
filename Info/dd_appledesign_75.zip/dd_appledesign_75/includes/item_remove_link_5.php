<?php
function item_remove_link_5() {
?>
<?php
}