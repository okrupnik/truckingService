<?php
function language_4() {
    $document = JFactory::getDocument();
    $view = $document->view;
    ?>
    <?php echo $view->position('language', '', '4', 'language'); ?>
    <?php
}