<?php
function item_remove_link_7() {
?>
<?php
}