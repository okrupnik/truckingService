<?php
function item_edit_link_6($product) {
    ?>
    <a class=" bd-itemeditlink-6" href="<?php echo $product['href']; ?>">
        <span class=" bd-icon-53"></span>
    </a>
<?php
}