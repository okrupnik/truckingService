<?php
function item_remove_link_6() {
?>
<?php
}