<?php
function item_edit_link_4($product) {
    ?>
    <a class=" bd-itemeditlink-4" href="<?php echo $product['href']; ?>">
        <span class=" bd-icon-46"></span>
    </a>
<?php
}