<?php
if( !SZKL_security() ) {
?><div class=" 
 col-md-10">
    <div class="bd-layoutcolumn-72"><div class="bd-vertical-align-wrapper"><img class="bd-imagestyles bd-imagelink-2   " src="<?php echo JURI::base() . 'templates/' . JFactory::getApplication()->getTemplate(); ?>/images/designer/79692467efa93aa1791d08971c3458b5_l.png"></div></div>
</div>
	
		<div class=" 
 col-md-14">
    <div class="bd-layoutcolumn-87"><div class="bd-vertical-align-wrapper"><div class=" bd-textblock-90 bd-tagstyles">
    Designed by <a href="http://www.diablodesign.eu" target="_blank">www.diablodesign.eu</a>.
</div></div></div>
</div>
<?php
}
?>
