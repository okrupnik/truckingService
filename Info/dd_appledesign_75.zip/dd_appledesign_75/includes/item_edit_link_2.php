<?php
function item_edit_link_2($product) {
    ?>
    <a class=" bd-itemeditlink-2" href="<?php echo $product['href']; ?>">
        <span class=" bd-icon-4"></span>
    </a>
<?php
}