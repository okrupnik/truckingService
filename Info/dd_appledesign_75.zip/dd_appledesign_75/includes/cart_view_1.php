<?php
function cart_view_1($href, $text) {
?>
    <a href="<?php echo $href; ?>" class=" bd-button"><?php echo $text; ?></a>
<?php
}