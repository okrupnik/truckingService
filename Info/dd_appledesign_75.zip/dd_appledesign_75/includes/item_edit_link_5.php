<?php
function item_edit_link_5($product) {
    ?>
    <a class=" bd-itemeditlink-5" href="<?php echo $product['href']; ?>">
        <span class=" bd-icon-51"></span>
    </a>
<?php
}