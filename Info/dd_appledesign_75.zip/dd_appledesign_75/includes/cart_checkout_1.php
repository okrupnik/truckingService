<?php
function cart_checkout_1() {
?>
    <a href="<?php echo JRoute::_ ('index.php?option=com_virtuemart&view=cart&task=checkout_task'); ?>" class=" bd-button">Checkout now</a>
<?php
}