<?php
function item_edit_link_1($product) {
    ?>
    <a class=" bd-itemeditlink-1" href="<?php echo $product['href']; ?>">
        <span class=" bd-icon-9"></span>
    </a>
<?php
}