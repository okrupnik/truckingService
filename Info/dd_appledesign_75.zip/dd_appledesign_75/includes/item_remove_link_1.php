<?php
function item_remove_link_1() {
?>
<?php
}