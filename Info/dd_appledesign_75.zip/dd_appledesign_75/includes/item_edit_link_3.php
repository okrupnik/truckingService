<?php
function item_edit_link_3($product) {
    ?>
    <a class=" bd-itemeditlink-3" href="<?php echo $product['href']; ?>">
        <span class=" bd-icon-29"></span>
    </a>
<?php
}